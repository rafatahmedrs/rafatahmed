print("informatique de gestion")
print("1er semestre 2019-2020")
print("Bonjour HEG!")
